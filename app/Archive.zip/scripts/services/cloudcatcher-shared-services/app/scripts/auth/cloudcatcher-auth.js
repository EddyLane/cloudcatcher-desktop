'use strict';

/**
 *
 * @ngInject
 * @param $q
 * @param $rootScope
 * @param $log
 * @param CloudcatcherApi
 * @param CloudcatcherAuthApi
 * @param CloudcatcherUser
 * @param FirebaseAuth
 * @constructor
 */
function CloudcatcherAuth($q, $rootScope, $log, CloudcatcherApi, CloudcatcherAuthApi, CloudcatcherUser, FirebaseAuth, GCM_ID) {

    /**
     * Get the cached offline data for this user
     *
     * @returns {Promise}
     */
    function getOfflineData() {

        var defer = $q.defer();

        chrome.storage.local.get('user', function (userData) {
            var user = CloudcatcherUser(userData.user);
            chrome.storage.local.get('podcasts', function (podcastData) {
                user.setPodcasts(podcastData.podcasts);
                defer.resolve(user);
            });
        });

        return defer.promise;
    }

    /**
     * Handle setting all firebase data on the CloudcatcherUser instance
     *
     * @param user
     * @returns {*}
     */
    function getFirebaseData(user) {

        /**
         * Set the podcasts on the user and cue up the episode counter
         *
         * @param podcasts
         * @returns {Promise}
         */
        function handlePodcasts(podcasts) {
            return $q.when(user.setPodcasts(podcasts));
        }

        /**
         * Set the currently playing on the user
         *
         * @param playing
         * @returns {Promise}
         */
        function handleCurrentPlaying(playing) {
            return $q.when(user.setCurrentPlaying(playing));
        }

        /**
         * Resolve the podcasts and currently playing for the user
         *
         * @param resolutions
         * @returns {Promise|*}
         */
        function resolveFirebase(resolutions) {

            var userResolutions = [
                handlePodcasts(resolutions[0]),
                handleCurrentPlaying(resolutions[1])
            ];

            return $q.all(userResolutions).then(function () {
                return user;
            });
        }

        /**
         * Handle the users resolved firebase
         *
         * @param userFirebase
         * @returns {Promise|*}
         */
        function handleFirebase(userFirebase) {
            return $q.all([userFirebase.getPodcasts(), userFirebase.getCurrentPlaying()]).then(resolveFirebase);
        }


        return FirebaseAuth(user).then(handleFirebase);

    }

    /**
     * Get complete CloudcatcherUser with firebase from data returned from the server
     *
     * @param promise
     * @returns {Promise}
     */
    function getUserData(promise) {
        return promise.then(function (userData) {
            return getFirebaseData(CloudcatcherUser(userData));
        });
    }

    /**
     * Register this client with GCM
     *
     * @returns {Promise}
     */
    function registerGcm(user) {
        var defer = $q.defer();
        chrome.gcm.register([GCM_ID], function (registrationId) {
            $log.info('client registed with GCM ID: ', registrationId, 'Attempting to post to cloudcatcher');
            chrome.storage.local.get('token', function (data) {
                CloudcatcherApi.one('users', user.getUsername()).post('gcms', { gcm_id: registrationId }, { access_token: data.token })
                    .then(function () {
                        chrome.storage.local.set({ registered: registrationId }, function () {
                            $log.info('successfully registerd GCM ID', registrationId, 'with cloudcatcher');
                            defer.resolve();
                        });
                    })
                    .catch(function () {
                        $log.error('Saving to cloudcatcher failed. Removing "registered" from local storage', arguments);
                        chrome.storage.local.remove('registered');
                        defer.reject();
                    })
                ;
            });
        });
        return defer.promise;
    }

    /**
     * Get user from session
     * @returns {Promise}
     */
    this.check = function (params) {
        $log.debug('checking credentials. Online? ', $rootScope.online);
        var check = $rootScope.online ? getUserData(CloudcatcherApi.one('users', 'me').get(params)) : getOfflineData();
        check.then(function (user) {
            chrome.storage.local.get('registered', function (data) {
                if (data.registered && _.find(user.getGcmIds(), { gcm_id: data.registered })) {
                    $log.info('client already registered with GCM', data.registered);
                } else {
                    $log.info('client not registered with GCM. Attempting to register now');
                    chrome.gcm.unregister(function () {
                        registerGcm(user);
                    });
                }
            });
        });
        return check;
    };

    /**
     * Get session
     *
     * @param username
     * @param password
     * @returns {Promise}
     */
    this.authenticate = function (username, password) {
        return CloudcatcherAuthApi.one('token', null).get({ username: username, password: password });
    };

    /**
     * Remove the token (and everything else) from localstorage
     *
     * @returns {Promise}
     */
    this.logout = function () {
        var defer = $q.defer();
        chrome.storage.local.remove(['token', 'refresh_token'], defer.resolve);
        return defer.promise;
    };

    /**
     * Register a user
     *
     * @param values
     * @returns {*}
     */
    this.register = function (values) {
        return CloudcatcherApi.all('users').post(values);
    };

}

/**
 * @ngdoc service
 * @name cloudcatcherSharedServices.Cloudcatcherauth
 * @description
 * # cloudcatcherSharedServices
 * Service in the cloudcatcherSharedServices.
 */
angular.module('cloudcatcherSharedServices')
    .service('CloudcatcherAuth', CloudcatcherAuth);
