'use strict';

/**
 * @ngInject
 * @param EpisodeCounter
 * @param $rootScope
 * @returns {User}
 * @constructor
 */
function CloudcatcherUser(EpisodeCounter, $log) {

    return function User(userData) {

        $log.debug(userData);

        var podcasts,
            $podcasts,
            $currentPlaying;

        chrome.storage.local.set({
            user: userData
        });

        var user = {

            getGcmIds: function () {
                return userData.gcm_ids;
            },

            getUsername: function () {
                return userData.username;
            },

            getEmail: function () {
                return userData.email;
            },

            getFirebaseToken: function () {
                return userData.firebase_token;
            },

            setCurrentPlaying: function (_currentPlaying_) {
                $currentPlaying = _currentPlaying_;
                return this;
            },

            getCurrentPlaying: function () {
                return $currentPlaying;
            },

            updateCurrentPlaying: function (episode) {
                $currentPlaying.$set(_.assign(episode.data, {
                    position: episode.position
                }));
            },

            setPodcasts: function (_podcasts_) {
                $podcasts = _podcasts_;
                podcasts = _podcasts_.$asArray();
                return this;
            },

            getPodcasts: function () {
                return podcasts;
            },

            getPodcast: function (slug) {
                return _.find(this.getPodcasts(), { slug: slug });
            },

            addPodcast: function (podcast) {
                var self = this;
                if (!this.findPodcast(podcast)) {
                    this.getPodcasts().$add(angular.copy(podcast.plain())).then(function () {
                        EpisodeCounter([self.findPodcast(podcast)]).then(function () {
                            self.savePodcast(podcast);
                        });
                    });
                }
                return this;
            },

            removePodcast: function (podcast) {
                var found = user.findPodcast(podcast);
                if (found) {
                    user.getPodcasts().$remove(found);
                    return true;
                }
                return false;
            },

            findPodcast: function (podcast) {
                return _.find(user.getPodcasts(), { itunesId: podcast.itunesId });
            },

            savePodcast: function (podcast) {
                var found, update;
                if (!_.isPlainObject(podcast)) {
                    return false;
                }
                found = this.findPodcast(podcast);
                update = {};
                if (podcast.heard) {
                    found.heard = podcast.heard;
                }
                console.log('updating', podcast);
                update[this.getPodcasts().$keyAt(found)] = _.omit(found, ['episodes', '$$hashKey', '$id', '$priority', 'imageUrl', 'downloading']);

                var storage = {};

                storage['podcasts'] = _(this.getPodcasts())
                    .filter(function (i) {
                        return _.isPlainObject(i);
                    })
                    .map(function (e) {
                        return _.omit(e, ['episodes', '$$hashKey', '$id', '$priority', 'imageUrl', 'downloading']);
                    })
                    .value();

                chrome.storage.local.set(storage);


                $podcasts.$update(update);
                return true;
            },

            saveAllPodcasts: function () {
                var self = this;
                _.each($podcasts, function (podcast) {
                    self.savePodcast(podcast);
                });
            },

            addHeard: function (podcast) {
                var self = this;
                return function (episode) {
                    if (!podcast.heard) {
                        podcast.heard = [];
                    }

                    if (episode.media && episode.media.url && podcast.heard.indexOf(episode.media.url) === -1) {
                        if (podcast.newEpisodes && podcast.newEpisodes > 0) {
                            podcast.newEpisodes--;
                        }
                        podcast.heard.push(episode.media.url);
                    }

                    self.savePodcast(podcast);
                };
            },

            hearAll: function (podcast) {
                var self = this;
                return function (episodes) {
                    if (!podcast.heard) {
                        podcast.heard = [];
                    }

                    _.each(episodes, function (episode) {
                        if (episode.media && episode.media.url && podcast.heard.indexOf(episode.media.url) === -1) {
                            podcast.heard.push(episode.media.url);
                        }
                    });

                    podcast.newEpisodes = 0;

                    self.savePodcast(podcast);
                };
            }
        };
//
//        $rootScope.$on('onPlay', function (event, episode) {
//            user.updateCurrentPlaying(episode);
//        });
//
//        $rootScope.$on('whilePlaying', function (event, episode) {
//            user.updateCurrentPlaying(episode);
//        });
//
//        $rootScope.$on('whileLoading', function (event, episode) {
//            user.updateCurrentPlaying(episode);
//        });

        return user;

    };
}

/**
 * @ngdoc service
 * @name cloudcatcherSharedServices.CloudcatcherUser
 * @description
 * # Cloudcatcheruser
 * Service in the cloudcatcherSharedServices.
 */
angular.module('cloudcatcherSharedServices')
    .factory('CloudcatcherUser', CloudcatcherUser);
