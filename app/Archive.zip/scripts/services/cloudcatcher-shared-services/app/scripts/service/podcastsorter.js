'use strict';

/**
 * @ngInject
 * @returns {{}}
 * @constructor
 */
function PodcastSorter() {

    var PodcastSorter = {};

    /**
     * Get a Sorter to function by a property of the objects
     *
     * @param podcasts
     * @returns {Sorter}
     */
    PodcastSorter.getSorter = function (podcasts) {

        /**
         *
         * @param type
         * @returns {*}
         * @constructor
         */
        function Sorter(type) {

            var sorted = _(podcasts).filter(function (e) {
                return _.isPlainObject(e);
            }).sortBy(type);

            switch (type) {
                case 'newEpisodes':
                case 'latest':
                    sorted.reverse();
            }

            podcasts = sorted.value();
            return podcasts;
        }

        return Sorter;

    };

    return PodcastSorter;

}

/**
 * @ngdoc service
 * @name cloudcatcherDesktopApp.PodcastSorter
 * @description
 * # PodcastSorter
 * Service in the cloudcatcherDesktopApp.
 */
angular.module('cloudcatcherSharedServices')
    .service('PodcastSorter', PodcastSorter);
