'use strict';

/**
 * @ngInject
 * @param $rootScope
 * @constructor
 */
function AudioPlayer($rootScope) {

    this.play = function (episode) {

        if (episode.dataUri || !episode.downloaded) {
            $rootScope.$emit('play', episode);
        }
        else {

            webkitRequestFileSystem(PERSISTENT, episode.downloaded, function (fs) {

                fs.root.getFile(episode.file, {}, function (fileEntry) {

                    fileEntry.file(function (file) {

                        episode.dataUri = window.URL.createObjectURL(file);
                        $rootScope.$emit('play', episode);


//                        var reader = new FileReader();
//                        reader.onloadend = function (e) {
//                            episode.dataUri = e.target.result;
//                            $rootScope.$emit('play', episode);
//                        };
//                        reader.readAsDataURL(file);
                    }, function (e) {
                        console.log('read e', e);
                    });

                });

            }, function (e) {
                console.log('e', e);
            });
        }

        this.playing = episode;

    };

}

/**
 * @ngdoc service
 * @name cloudcatcherDesktopApp.AudioPlayer
 * @description
 * # AudioPlayer
 * Service in the cloudcatcherDesktopApp.
 */
angular.module('cloudcatcherSharedServices')
    .service('AudioPlayer', AudioPlayer);
