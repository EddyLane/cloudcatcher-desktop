'use strict';

/**
 * The ItunesPodcastApi
 *
 * @param Restangular
 * @param ITUNES_URL
 * @param $filter
 * @returns {*}
 * @constructor
 */
function ItunesPodcastApi(Restangular, ITUNES_URL, $filter) {

    /**
     * Configure a Restangular instance
     *
     * @param RestangularConfigurer
     * @constructor
     */
    function Configurer (RestangularConfigurer) {

        RestangularConfigurer.setJsonp(false);
        RestangularConfigurer.setDefaultRequestParams('get', { media: 'podcast' });
        RestangularConfigurer.setBaseUrl(ITUNES_URL);
        RestangularConfigurer.addResponseInterceptor(ResponseInterceptor);

        /**
         * Format results
         *
         * @param data
         * @returns {Array|*}
         * @constructor
         */
        function ResponseInterceptor (data) {
            return data.results.map(function (result) {
                return {
                    episodes: {},
                    heard: [],
                    name: result.collectionName,
                    slug: result.collectionName ? $filter('slugify')(result.collectionName) : undefined,
                    artist: result.artistName,
                    itunesId: result.collectionId,
                    feed: result.feedUrl,
                    artwork: {
                        30: result.artworkUrl30,
                        100: result.artworkUrl100
                    },
                    latest: result.releaseDate,
                    explicit: result.collectionExplicitness !== 'notExplicit',
                    amount: result.trackCount,
                    country: result.country,
                    genres: _.without(result.genres, 'Podcasts')
                };
            });
        }

    }

    return Restangular.withConfig(Configurer);

}
/**
 * @ngdoc service
 * @name uvdRESTfulApp.ItunesPodcastApi
 * @description
 * # ItunesPodcastApi
 * Service in the uvdRESTfulApp.
 */
angular.module('cloudcatcherSharedServices')
    .factory('ItunesPodcastApi', ItunesPodcastApi);