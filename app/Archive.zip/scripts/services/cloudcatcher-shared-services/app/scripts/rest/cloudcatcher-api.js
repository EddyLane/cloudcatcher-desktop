'use strict';

/**
 * @ngdoc service
 * @name cloudcatcherDesktopApp.CloudcatcherApi
 * @description
 * # CloudcatcherApi
 * Service in the cloudcatcherDesktopApp.
 */


angular.module('cloudcatcherSharedServices')

    .service('CloudcatcherToken', function CloudcatcherToken ($q, Restangular, CLOUDCATCHER_AUTH_URL, CLOUDCATCHER_AUTH_CLIENT_ID, CLOUDCATCHER_AUTH_CLIENT_SECRET, $state) {

        var RestangularRefresh = Restangular.withConfig(function (RestangularConfigurer) {
            RestangularConfigurer.setBaseUrl(CLOUDCATCHER_AUTH_URL);
            RestangularConfigurer.setDefaultRequestParams({
                client_id: CLOUDCATCHER_AUTH_CLIENT_ID,
                client_secret: CLOUDCATCHER_AUTH_CLIENT_SECRET,
                grant_type: 'refresh_token'
            });
            RestangularConfigurer.setErrorInterceptor(function() {
                $state.go('login');
            });
        });

        this.refresh = function (config) {
            var deferred = $q.defer();
            var self = this;
            chrome.storage.local.get('refresh_token', function (data) {
                RestangularRefresh.one('token', null).get({ refresh_token: data.refresh_token })
                    .then(function (data) {
                        self.set(data.access_token, data.refresh_token);
                        config.params.access_token = data.access_token;
                        deferred.resolve(config);
                    })
                ;
            });
            return deferred.promise;
        };

        this.get = function () {
            var defer = $q.defer();
            chrome.storage.local.get('token', defer.resolve);
            return defer.promise;
        };

        this.set = function (token, refresh_token) {
            chrome.storage.local.set({
                token: token,
                refresh_token: refresh_token
            });
        };

    })

    .factory('CloudcatcherApi', function CloudcatcherApi(Restangular, CLOUDCATCHER_URL, CloudcatcherToken, $http, $q) {
        return Restangular.withConfig(function (RestangularConfigurer) {
            RestangularConfigurer.setBaseUrl(CLOUDCATCHER_URL);

            function setToken (data) {
                RestangularConfigurer.setDefaultRequestParams({
                    access_token: data.token
                });
            }

            RestangularConfigurer.setErrorInterceptor(function(response, deferred, responseHandler) {


                if(response.status === 403 || response.status === 401) {
                    CloudcatcherToken.refresh(response.config).then(function(config) {
                        $http(config).then(function (res) {
                            deferred.resolve(res.data);
                        }, deferred.reject);
                    });
                    return false;
                }

                return true; // error not handled
            });

            RestangularConfigurer.addRequestInterceptor(function (element) {
                console.log(arguments);
                CloudcatcherToken.get().then(setToken);
                return element;
            });

            RestangularConfigurer.addResponseInterceptor(function (data) {
                console.log(arguments);
                return data;
            });

            chrome.storage.onChanged.addListener(setToken);

        });
    })

    .factory('CloudcatcherAuthApi', function CloudcatcherAuthApi(Restangular, CLOUDCATCHER_AUTH_URL, CLOUDCATCHER_AUTH_CLIENT_ID, CLOUDCATCHER_AUTH_CLIENT_SECRET, CloudcatcherToken, $http) {
        return Restangular.withConfig(function (RestangularConfigurer) {
            RestangularConfigurer.setBaseUrl(CLOUDCATCHER_AUTH_URL);
            RestangularConfigurer.setErrorInterceptor(function(response, deferred) {

                if(response.status === 403 || response.status === 401) {
                    CloudcatcherToken.refresh(response.config).then(function(config) {
                        $http(config).then(function (res) {
                            deferred.resolve(res.data);
                        }, deferred.reject);
                    });
                    return false;
                }

                return true; // error not handled
            });

            RestangularConfigurer.setDefaultRequestParams({
                client_id: CLOUDCATCHER_AUTH_CLIENT_ID,
                client_secret: CLOUDCATCHER_AUTH_CLIENT_SECRET,
                grant_type: 'password'
            });

            RestangularConfigurer.addResponseInterceptor(function (data) {
                CloudcatcherToken.set(data.access_token, data.refresh_token);
                return data;
            });

        });
    })

;