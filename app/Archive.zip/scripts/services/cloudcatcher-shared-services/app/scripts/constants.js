angular.module("cloudcatcherConstants", [])

.constant("ITUNES_URL", "https://itunes.apple.com/")

.constant("CLOUDCATCHER_URL", "https://arcane-river-7182.herokuapp.com/app.php/api/v1/")
//.constant("CLOUDCATCHER_URL", "http://app.angular-symfony-stripe.local:8080/app_dev.php/api/v1/")

.constant("CLOUDCATCHER_AUTH_URL", "https://arcane-river-7182.herokuapp.com/app.php/oauth/v2/")
//.constant("CLOUDCATCHER_AUTH_URL", "http://app.angular-symfony-stripe.local:8080/app_dev.php/oauth/v2/")

.constant('CLOUDCATCHER_AUTH_CLIENT_ID', '1_1wp0z2iv4ckksoc4c4s0owkcg08o4k0sc4wogw4w880cossgkc')
//.constant('CLOUDCATCHER_AUTH_CLIENT_ID', '8_5az5vu5bvv4sow0sow8o00oo44kws8wsgo40oso404s0480g4k')

.constant('CLOUDCATCHER_AUTH_CLIENT_SECRET', '1k62lrlogkskgggk88wowcckk0gcwwwc44oogog0s88ccsw44o')
//.constant('CLOUDCATCHER_AUTH_CLIENT_SECRET', '12szvzzluuaokcgcwg8kccsscko8w4kgcg8wwow40c8oko8csg')

.constant("GOOGLE_FEED_URL", "http://ajax.googleapis.com/ajax/services/feed/")

.constant("FIREBASE_URL", "https://podcatcher.firebaseio.com")

.constant('GCM_ID', "74283247353")

;